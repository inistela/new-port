package com.cro;

public class coloDto {
	private String lib;

	public coloDto(String lib) {
		super();
		this.lib = lib;
	}

	public coloDto() {
	}

	public String getLib() {
		return lib;
	}

	public void setLib(String lib) {
		this.lib = lib;
	}

}
